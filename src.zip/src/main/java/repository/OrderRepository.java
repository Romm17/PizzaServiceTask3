package repository;

import domain.Order;

/**
 * @author Roman Usik
 */
public interface OrderRepository {

    int saveOrder(Order order);

}
