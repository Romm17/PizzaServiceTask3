package repository;

import domain.Order;

import java.util.LinkedList;
import java.util.List;

/**
 * @author Roman Usik
 */
public class LocalOrderRepository implements OrderRepository {

    private List<Order> orderList;

    public LocalOrderRepository() {

        orderList = new LinkedList<>();

    }

    @Override
    public int saveOrder(Order toSave) {

        orderList.add(toSave);
        return 0;

    }

}
