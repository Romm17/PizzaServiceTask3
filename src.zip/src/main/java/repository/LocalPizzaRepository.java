package repository;

import domain.Pizza;
import domain.PizzaType;

import java.util.LinkedList;
import java.util.List;

/**
 * @author Roman Usik
 */
public class LocalPizzaRepository implements PizzaRepository {

    private List<Pizza> pizzaList;

    public LocalPizzaRepository() {

        pizzaList = new LinkedList<>();

    }

    public void init(){

        pizzaList.add(new Pizza(PizzaType.Neapolitano, "Marinara", 10));
        pizzaList.add(new Pizza(PizzaType.Neapolitano, "Margherita", 20));
        pizzaList.add(new Pizza(PizzaType.DeepDish, "SimpleDeepDish", 30));
        pizzaList.add(new Pizza(PizzaType.Sicilian, "WithOil", 40));

    }

    @Override
    public Pizza getPizzaByID(int id) {

        for (Pizza p : pizzaList) {
            if (p.getId() == id) {
                return p;
            }
        }
        return null;

    }

}
