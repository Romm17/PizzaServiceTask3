package repository;

import domain.Pizza;

/**
 * @author Roman Usik
 */
public interface PizzaRepository {

    Pizza getPizzaByID(int id);
}
