package service;

import domain.Customer;
import domain.Order;

/**
 * @author Roman Usik
 */
public interface OrderService {
    Order placeNewOrder(Customer customer, Integer... pizzasID);
}
