package service;

import domain.Customer;
import domain.Order;
import domain.Pizza;
import infrastructure.Benchmark;
import repository.OrderRepository;
import repository.PizzaRepository;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Roman Usik
 */
public class SimpleOrderService implements OrderService {

    private PizzaRepository pizzaRepository;
    private OrderRepository orderRepository;

    public SimpleOrderService(PizzaRepository pizzaRepository,
                              OrderRepository orderRepository)
    {
        this.pizzaRepository = pizzaRepository;
        this.orderRepository = orderRepository;
    }

    @Override
    @Benchmark
    public Order placeNewOrder(Customer customer, Integer... pizzasID) {

        List<Pizza> pizzas = new ArrayList<>();

        for(Integer id : pizzasID){
            pizzas.add(pizzaRepository.getPizzaByID(id)); // get Pizza from predifined in-memory list
        }

        Order newOrder = new Order(customer, pizzas);

        orderRepository.saveOrder(newOrder); // set Order Id and save Order to in-memory list
        return newOrder;

    }

}

