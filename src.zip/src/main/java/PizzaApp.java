import domain.Customer;
import domain.Order;
import infrastructure.*;
import repository.PizzaRepository;
import service.OrderService;

/**
 * @author Roman Usik
 */
public class PizzaApp {

    public static void main(String[] args) throws Exception {

        Config config = new JavaConfig();

        ApplicationContext context = new JavaConfigApplicationContext(config);

        Customer customer = new Customer("Customer");
        Order order;

        PizzaRepository pizzaRepository = (PizzaRepository) context.getBean("pizzaRepository");

        System.out.println(pizzaRepository);
        System.out.println(pizzaRepository.getPizzaByID(1));

        OrderService orderService = (OrderService) context.getBean("orderService");
        order = orderService.placeNewOrder(customer, 1, 2, 3);

        System.out.println(order);

    }

}
