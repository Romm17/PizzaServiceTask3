package domain;

import domain.Customer;
import domain.Pizza;

import java.util.Iterator;
import java.util.List;

/**
 * @author Roman Usik
 */
public class Order {

    private static int ID = 1;

    private int id;
    private List<Pizza> pizzaList;
    private Customer customer;

    public Order(Customer customer, List<Pizza> pizzaList) {
        this.id = ID++;
        this.customer = customer;
        this.pizzaList = pizzaList;
    }

    public float getPrice() {
        float res = 0;
        for (Pizza p : pizzaList) {
            res += p.getPrice();
        }
        return res;
    }

    @Override
    public String toString() {
        String res = "{ \"order\" : \"" + id + "\", \"customer\" : "
                    + customer.toString()
                    + ", \"pizzas\" : {";
        Iterator<Pizza> i = pizzaList.iterator();
        for (;i.hasNext();) {
            res += i.next().toString();
            if (i.hasNext())
                res += ", ";
        }
        res += "}";
        return res;
    }

}
