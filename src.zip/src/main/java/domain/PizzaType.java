package domain;

/**
 * @author Roman Usik
 */
public enum PizzaType {
    Neapolitano,
    DeepDish,
    Sicilian
}
