package domain;

/**
 * @author Roman Usik
 */
public class Pizza {

    private static int ID = 1;

    private int id;
    private PizzaType type;
    private String name;
    private float price;

    public Pizza() {
        this.id = ID++;
    }

    public Pizza(PizzaType type, String name, float price) {
        this();
        this.type = type;
        this.name = name;
        this.price = price;
    }

    public int getId() {
        return id;
    }

    @Override
    public String toString() {
        return "{\"id\" : \"" + id + "\", \"name\" : \"" + name + "\", \"price\" : \"" + price + "\"}";
    }

    public float getPrice() {
        return price;
    }
}
