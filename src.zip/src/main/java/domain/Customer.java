package domain;

/**
 * @author Roman Usik
 */
public class Customer {

    private static int ID = 1;

    private int id;
    private String name;

    public Customer() {
        this.id = ID++;
    }

    public Customer(String name) {
        this();
        this.name = name;
    }

    @Override
    public String toString() {
        return "{ \"id\" : \"" + id + "\", \"name\" : \"" + name + "\"}";
    }
}
